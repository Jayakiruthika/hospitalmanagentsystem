import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-medicos-details',
  templateUrl: './medicos-details.component.html',
  styleUrls: ['./medicos-details.component.css']
})
export class MedicosDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
