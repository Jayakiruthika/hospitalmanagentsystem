export class Specialization{
    specId: number;
    speciality: string;
}