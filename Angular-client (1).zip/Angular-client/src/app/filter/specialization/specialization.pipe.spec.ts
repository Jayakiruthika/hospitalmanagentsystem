import { SpecializationPipe } from './specialization.pipe';

describe('SpecializationPipe', () => {
  it('create an instance', () => {
    const pipe = new SpecializationPipe();
    expect(pipe).toBeTruthy();
  });
});
