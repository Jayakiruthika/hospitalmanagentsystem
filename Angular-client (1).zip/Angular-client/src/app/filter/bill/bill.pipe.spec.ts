import { BillPipe } from './bill.pipe';

describe('BillPipe', () => {
  it('create an instance', () => {
    const pipe = new BillPipe();
    expect(pipe).toBeTruthy();
  });
});
