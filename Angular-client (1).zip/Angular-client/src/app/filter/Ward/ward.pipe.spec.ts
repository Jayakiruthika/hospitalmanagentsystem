import { WardPipe } from './ward.pipe';

describe('WardPipe', () => {
  it('create an instance', () => {
    const pipe = new WardPipe();
    expect(pipe).toBeTruthy();
  });
});
