import { MedicosPipe } from './medicos.pipe';

describe('MedicosPipe', () => {
  it('create an instance', () => {
    const pipe = new MedicosPipe();
    expect(pipe).toBeTruthy();
  });
});
