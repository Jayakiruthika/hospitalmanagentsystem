import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ward-deatils',
  templateUrl: './ward-deatils.component.html',
  styleUrls: ['./ward-deatils.component.css']
})
export class WardDeatilsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
