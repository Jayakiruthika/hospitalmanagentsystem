import { OperationPipe } from './operation.pipe';

describe('OperationPipe', () => {
  it('create an instance', () => {
    const pipe = new OperationPipe();
    expect(pipe).toBeTruthy();
  });
});
